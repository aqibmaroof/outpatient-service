globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/3iPWtDriQMC1aW7u5dJky/_buildManifest.js",
    "static/3iPWtDriQMC1aW7u5dJky/_ssgManifest.js",
    "static/3iPWtDriQMC1aW7u5dJky/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1guoti84v2fh3.js",
    "static/chunks/0ha4m18glnjqn.js",
    "static/chunks/07694pm6o3mg7.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/15orcrkp-_9ct.js",
    "static/chunks/turbopack-17hf92qmabun5.js"
  ]
};
